# Django Day 06

## 验证系统

+ 开启,settings.py将INSTALLED_APPS下'django.contrib.auth'启用

+ 玩转API的形式
  + manage.py shell

```python
    import django
    django.setup()
    from django.contrib.auth.models import User
    yk = User()
    yk.username = 'yangkun'
    yk.set_password('redhat')
    yk.email='yangwawa0323@163.com'
    yk.save()
```