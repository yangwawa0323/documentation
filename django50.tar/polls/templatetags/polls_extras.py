from django import template

register = template.Library()

def swap(value):
    return value.swapcase()

def mycut(value, length):
    return "%s..." % value[:length]

@register.filter(name="mytitle")
def mytitle(value):
    words= value.split(' ')
    con_words= []
    for w in words:
        firstChar = w[:1].upper()
        remainString = w[1:].lower()
        con_words.append( "%s%s" % (firstChar,remainString) )
    return ' '.join(con_words)
    #return ' '.join([ "%s%s" % (v[:1].upper(),v[1:].lower()) for v in value.split(' ') ])

register.filter('swap', swap)
register.filter('mycut', mycut)