from django.conf.urls import url

from . import views

urlpatterns = [
    # url(r'^home/$', views.sayhello, name='home'),
    url(r'^$', views.index, name='index'),
    url(r'^aboutus/$', views.aboutus, name="aboutus"),
    url(r'^detail/(?P<qid>[0-9]+)/$', views.detail, name="detail"),
    url(r'^public/$', views.public_benefit, name='public'),
    url(r'^search/$', views.search, name='search'),
    url(r'^handlesearch/$', views.handle_search, name='handle_search'),
    # url(r'^students/$', views.get_students, name="students"),
    url(r'^login/$', views.checkLogin, name='login'),
#########################################################################################
    # Management URL

    url(r'^controlpane/$', views.controlpane, name='controlpane'),

    url(r'^management/scan/$', views.scan, name='scan'),
    url(r'^management/backup/(?P<dbname>[a-zA-Z][0-9a-zA-Z]+)/$', views.backup, name='backup'),
    url(r'^management/clean/$', views.clean, name='clean'),



]