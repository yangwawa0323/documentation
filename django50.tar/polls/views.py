# coding: utf-8
# encoding: utf-8
from django.shortcuts import render,redirect
from django.http import HttpResponse, Http404
from django.core.urlresolvers import reverse
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from mysite.settings import MYSQLDUMP
import shlex
import subprocess
import datetime

import sys
reload(sys)
sys.setdefaultencoding('utf8')

import random
# Create your views here.
from .models import Question, Student

####################### 管理级的视图函数 ##########################################################
def controlpane(request):
    if request.user.is_authenticated():
        return render(request,'polls/management/controlpane.html')
    else:
        return redirect(reverse('index'))

def scan(request):
    if request.user.is_authenticated():
        return HttpResponse('scanning...')
    else:
        return redirect(reverse('index'))

@login_required
def backup(request,dbname):
    command = 'mysqldump -u%s -p%s %s' % ( 
        MYSQLDUMP['user'], MYSQLDUMP['password'], dbname)
    
    cmdlist = shlex.split(command)
    today = datetime.datetime.today().strftime('%Y-%m-%d')
    # return HttpResponse(today)
    try:
        result = subprocess.check_output(cmdlist)
        f = open('/tmp/%s.%s.sql' % (dbname,today),'w')
        f.write(result)
        f.close()
    except:
        return HttpResponse('备份失败,用户名密码不正确,数据库不存在')
    return HttpResponse(result)

@login_required
def clean(requst):
    return HttpResponse('Clean temporary files...')

################################################################################################
def checkLogin(request):
    username = request.GET['username']
    password = request.GET['password']

    user = authenticate(username=username, password=password)
    if user:
        # 一旦用户验证成功,要立即建立会话所用到的session,保存用户在后续(不关掉浏览器)
        # 的通讯过程中的访问此用户信息
        request.session.set_expiry(0)
        login(request,user)
        return controlpane(request)
    else:
        return HttpResponse('用户名不存在或者密码错误!')
    # output = "User: %s, Password: %s" % (username, password)

    # return HttpResponse(output)

def search(request):
    return render(request, 'polls/search.html')

def handle_search(request):
    keyword = request.GET['keyword']
    qs = Question.objects.filter(question_text__icontains=keyword)
    return render(request, 'polls/search_result.html', { "qs": qs})

def detail(request,qid):
    try:
        q = Question.objects.get(id=qid)
    except Question.DoesNotExist:
        return redirect(  reverse('public') )
        # return public_benefit(request)
    return render(request, 'polls/detail.html', { 'q': q} )


def public_benefit(request):
    return render(request, 'polls/public.html')

def get_students(req):
    students = Student.objects.all()
    return render(req, 'polls/students.html',
        { 'students': students , 'author' : 'yangkun'})

def index(req):
    ''' req: django.http.HttpRequest instance..'''
    questions = Question.objects.all()[:10]
    ad_pages  = ['polls/ad.html','polls/computer.html',]
    ad_page =  random.choice(ad_pages)
    return render(req, 'polls/index.html', 
        {'questions': questions , 'ad_page': ad_page
            ,'author': 'y   a  n  g  w  a  wa  0323@163.com'
            ,'percentage': 79, 'profit': 20,})
    # output = ''
    # for q in qs:
    #     output += "<p style='background-color:lightblue;'>%s</p>" % q.question_text
    # return HttpResponse(output)
    

# def sayhello(request):
#     ''' request: django.http.HttpRequest instance'''
#     return render(request, 'polls/index.html')

def aboutus(request):
    return render(request, 'polls/aboutus.html')